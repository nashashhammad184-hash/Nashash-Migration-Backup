#!/usr/bin/env bash
# Static verify only. Does not run GPU.
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
echo "[verify_i2v_baseline] checking manifest files"
for f in I2V_BASELINE.txt MODEL_MANIFEST.txt KAYANGPU_MANIFEST.txt; do
  test -s "$SRC/manifests/$f" && echo "  OK $f" || echo "  MISSING $f"
done
echo "[verify_i2v_baseline] to verify actual I2V on GPU, run worker with distill_method=dmd2 and check face_ratio>=0.7"
