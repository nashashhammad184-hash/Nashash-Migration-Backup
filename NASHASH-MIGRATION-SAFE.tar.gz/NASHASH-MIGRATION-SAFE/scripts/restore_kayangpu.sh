#!/usr/bin/env bash
# Restore KayanGPU worker to a fresh GPU instance.
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
echo "[restore_kayangpu] Steps (execute manually after new GPU instance is ready):"
echo "1) copy $SRC/kayan-gpu/worker_main.py  -> GPU:/opt/kayangpu/api/main.py"
echo "2) copy $SRC/kayan-gpu/worker_main.py.bak-20260929-130731 -> GPU:/opt/kayangpu/api/main.py.bak-20260929-130731"
echo "3) copy .env (KAYANGPU_API_KEY) -> GPU:/opt/kayangpu/api/.env"
echo "4) systemd unit: /etc/systemd/system/kayangpu-worker.service (see KAYANGPU_MANIFEST.txt)"
echo "5) install LightX2V 0.5.0 in /data/lightx2v_test/venv (see GPU_ENVIRONMENT.txt)"
echo "6) place I2V Step-Distilled checkpoint (see MODEL_MANIFEST.txt)"
echo "7) sudo systemctl daemon-reload && sudo systemctl enable --now kayangpu-worker"
