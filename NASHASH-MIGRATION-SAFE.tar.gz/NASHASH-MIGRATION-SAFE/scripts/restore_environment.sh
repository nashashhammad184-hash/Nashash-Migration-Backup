#!/usr/bin/env bash
set -euo pipefail
echo "[restore_environment] Reference only."
echo "  - OS: Ubuntu (see GPU_ENVIRONMENT.txt)"
echo "  - Node 22.x, pnpm 11.x"
echo "  - PostgreSQL (see NASHASH_SERVER_MANIFEST.txt)"
echo "  - Python venv: /data/lightx2v_test/venv (GPU side)"
