#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
echo "[restore_database] Will restore DBs from $SRC/database/"
echo "  sudo -u postgres pg_restore -d dbname --clean --if-exists $SRC/database/nashash_database.dump"
echo "  sudo -u postgres pg_restore -d kayan  --clean --if-exists $SRC/database/kayan_queue.dump"
echo "[restore_database] Run those commands manually. Nothing executed."
