#!/usr/bin/env bash
# Nashash Server Restore — SAFE. Does not delete anything.
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${TARGET_NASHASH_DIR:-/home/ubuntu/Nashash}"
echo "[restore_server] Source=$SRC Target=$TARGET"
if [ ! -d "$TARGET" ]; then
  echo "Target dir $TARGET does not exist. Create it manually or set TARGET_NASHASH_DIR."
  exit 1
fi
echo "[restore_server] This script only COPIES restore scripts/manifests, does NOT overwrite production."
echo "[restore_server] 1) restore DB:  sudo -u postgres pg_restore -d dbname --clean --if-exists $SRC/database/nashash_database.dump"
echo "[restore_server] 2) restore queue DB: sudo -u postgres createdb kayan; sudo -u postgres pg_restore -d kayan --clean --if-exists $SRC/database/kayan_queue.dump"
echo "[restore_server] 3) copy ssh key: cp $SRC/scripts/kayan_gpu.key ~/.ssh/kayan_gpu && chmod 600 ~/.ssh/kayan_gpu"
echo "[restore_server] 4) restore .env from your secure store (see .env.example.txt for names)"
echo "[restore_server] 5) cd $TARGET && pnpm install && pnpm build"
echo "[restore_server] 6) PM2 start: see scripts/restore_pm2.sh"
echo "[restore_server] DONE (no files modified)."
