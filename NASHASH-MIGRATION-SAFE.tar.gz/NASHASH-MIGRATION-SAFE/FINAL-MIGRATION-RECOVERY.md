# FINAL MIGRATION RECOVERY

Generated: 2026-09-30
Purpose: single source of truth for restoring Nashash + Kayan Studio
on a new hosting provider.

================================================================
CHECKPOINT_STATUS
================================================================
CHECKPOINT_STATUS=LOST
CHECKPOINT_RESTORE_REQUIRED=YES
CHECKPOINT_DURABLE_BACKUP=BLOCKED

The 33.3 GB I2V Step-Distilled transformer checkpoint was lost when the
AWS g5.xlarge instance was stopped. AWS Instance Store
(/opt/dlami/nvme) is ephemeral and does NOT persist across Stop/Start.

What SURVIVED on EBS (/data):
  - /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/config.json  (use_meanflow=true)
  - /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v/{config.json, additional.safetensors, byt5_mapper.safetensors}
  - /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_t2v/diffusion_pytorch_model.safetensors (33 GB)
  - /data/models/video/hunyuanvideo-1.5/ckpts/text_encoder/
  - /data/models/video/hunyuanvideo-1.5/ckpts/vae/
  - /data/models/video/hunyuanvideo-1.5/ckpts/vision_encoder/siglip/
  - /data/models/lightx2v/hy1.5_t2v_480p_scaled_fp8_e4m3_lightx2v_4step.safetensors
  - /data/models/lightx2v/hy15_480p_i2v_cfg_distilled_fp8_e4m3_lightx2v.safetensors (deprecated)

================================================================
REQUIRED CHECKPOINT
================================================================
Repo:      tencent/HunyuanVideo-1.5
Path:      transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors
Size:      33,325,523,336 bytes (~33.3 GB)
Type:      HunyuanVideo_1_5_DiffusionTransformer (F32, 1797 keys)
Config:    use_meanflow=true

Download command:
  /data/lightx2v_test/venv/bin/hf download tencent/HunyuanVideo-1.5 \
    transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors \
    transformer/480p_i2v_step_distilled/config.json \
    --local-dir /data/models/video/hunyuanvideo-1.5/ckpts

Then create symlinks in the target dir:
  cd /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/
  ln -sf ../480p_i2v/additional.safetensors additional.safetensors
  ln -sf ../480p_i2v/byt5_mapper.safetensors byt5_mapper.safetensors

Verification:
  stat -c "%s" diffusion_pytorch_model.safetensors   # 33325523336
  /data/lightx2v_test/venv/bin/python -c "
from safetensors import safe_open
p='diffusion_pytorch_model.safetensors'
with safe_open(p, framework='pt', device='cpu') as f:
    print('keys', len(list(f.keys())))                # 1797
    print('img_in.proj.weight', f.get_slice('img_in.proj.weight').get_shape())  # [2048,65,1,1,1]
"

================================================================
I2V VERIFIED CONFIGURATION (proven 2026-09-29)
================================================================
distill_method          = dmd2
sample_shift            = 7.0
denoising_step_list     = [1000, 875, 750, 625, 500, 375, 250, 125]
guidance_scale          = 1
num_frames              = 81
fps                     = 16
aspect_ratio            = 16:9
output_resolution       = 640x640
input_bucket            = 480p
use_meanflow            = true

Worker overrides (optional, in /opt/kayangpu/api/.env):
  KAYAN_I2V_CKPT          = /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors
  KAYAN_I2V_TRANSFORMER   = 480p_i2v_step_distilled

Reference image (base64) REQUIRED per i2v job.

================================================================
REQUIRED RUNTIME ENVIRONMENT
================================================================
GPU:      NVIDIA A10G (22.1 GB usable VRAM min for 81-frame I2V)
Driver:   595.91.07 (min ~545 compatible with cu128)
CUDA:     12.8 (via PyTorch wheels)
PyTorch:  2.8.0+cu128
Python:   3.12.3
FFmpeg:   on PATH
LightX2V: 0.5.0
venv:     /data/lightx2v_test/venv

================================================================
REQUIRED KAYANGPU STARTUP
================================================================
systemd unit: /etc/systemd/system/kayangpu-worker.service
Override:     TimeoutStartSec=1800 (cold-load I2V takes ~15 min)
ExecStart:    /data/lightx2v_test/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8080
WorkingDir:   /opt/kayangpu/api
User:         ubuntu

EnvironmentFile: /opt/kayangpu/api/.env
  Requires KAYANGPU_API_KEY=<token>

================================================================
REQUIRED NASHASH GPU CONNECTION
================================================================
In /home/ubuntu/Nashash/.env:
  GPU_SSH_TARGET = ubuntu@<new-gpu-public-ip>
  GPU_WORKER_URL = http://127.0.0.1:8080
  GPU_WORKER_TOKEN = <must match KAYANGPU_API_KEY on GPU>
  GPU_SSH_KEY   = /home/ubuntu/.ssh/kayan_gpu

SSH tunnel (persistent):
  ssh -i /home/ubuntu/.ssh/kayan_gpu -f -N \
    -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes \
    -L 8080:127.0.0.1:8080 -L 8082:127.0.0.1:8082 \
    ubuntu@<new-gpu-public-ip>

================================================================
GPU_WORKER_TOKEN SYNCHRONIZATION PROCEDURE
================================================================
Token is shared between:
  - Nashash: /home/ubuntu/Nashash/.env  (GPU_WORKER_TOKEN)
  - GPU:     /opt/kayangpu/api/.env     (KAYANGPU_API_KEY)

Rotation must be done in a single maintenance window:

  1) Generate new token (any secure 64-char hex string).
  2) On GPU: edit /opt/kayangpu/api/.env → KAYANGPU_API_KEY=<new>
     sudo systemctl restart kayangpu-worker
  3) Verify on GPU: curl -s -H "X-API-Key: <new>" http://127.0.0.1:8080/health
  4) On Nashash: edit /home/ubuntu/Nashash/.env → GPU_WORKER_TOKEN=<new>
     pm2 restart nashash-app nashash-queue --update-env
  5) Confirm no auth failures in /data/logs/kayangpu-worker.log.

If either side fails, revert both sides to the previous token.

================================================================
RECOVERY STEP ORDER (new host)
================================================================
1) Provision server (Ubuntu 24.04), install PostgreSQL 16, Node 22, pnpm 11.
2) Clone/copy Nashash source from the safe archive.
3) Restore DBs:
     sudo -u postgres pg_restore -d dbname --clean --if-exists nashash_database.dump
     sudo -u postgres createdb kayan
     sudo -u postgres pg_restore -d kayan  --clean --if-exists kayan_queue.dump
4) Recreate /home/ubuntu/Nashash/.env from .env.example.txt (fill real secrets).
5) pnpm install && pnpm build.
6) pm2 start queue-worker + app; pm2 save.
7) Provision GPU host (g5.xlarge or equivalent, A10G 24 GB).
8) Create /data/lightx2v_test/venv from GPU_ENVIRONMENT_FINAL.txt pip freeze.
9) Install LightX2V 0.5.0 + copy worker main.py + systemd unit.
10) Download I2V Step-Distilled checkpoint (see CHECKPOINT section above).
11) Start kayangpu-worker; verify /health returns 200.
12) On Nashash: update GPU_SSH_TARGET to new GPU IP; restart tunnel; pm2 restart.
13) Run ONE direct I2V smoke test (81 frames, seed 123, ref test_char_face.jpg).
    Face detection ratio must be >= 0.7 on sampled frames.

================================================================
KNOWN ISSUES / PITFALLS
================================================================
- AWS Instance Store does NOT survive Stop/Start. Any checkpoint on
  /opt/dlami/nvme is lost permanently.
- PM2 caches env at start. Always `pm2 delete` + `pm2 start` fresh if
  env changes; do not rely on `pm2 restart` alone.
- CFG-Distilled FP8 checkpoint is incompatible with Step-Distilled scheduler.
  Only use the official Step-Distilled F32 checkpoint.
- seed=123 + same prompt + same reference → deterministic output.
