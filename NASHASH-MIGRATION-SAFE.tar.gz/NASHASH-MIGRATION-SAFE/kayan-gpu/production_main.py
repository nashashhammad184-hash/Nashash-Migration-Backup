"""
KayanGPU Worker API
- GET  /health
- POST /jobs/video
- GET  /jobs/{job_id}
- POST /jobs/{job_id}/cancel
"""
import subprocess
import threading
import time
import uuid
from collections import OrderedDict
from datetime import datetime
from queue import Queue, Empty
from typing import Optional

import os
from fastapi import FastAPI, HTTPException, Header, Depends
from pydantic import BaseModel, Field

API_KEY = os.environ.get("KAYANGPU_API_KEY")
if not API_KEY:
    raise RuntimeError("KAYANGPU_API_KEY environment variable is required and not set")

MAX_PROMPT_LENGTH = 2000

# ===================================================
# KAYAN-GPU-AGNOSTIC-17: Dynamic Compute Configuration
# ===================================================
def detect_compute_config():
    gpu_name = os.environ.get("GPU_NAME")
    gpu_vram = os.environ.get("GPU_VRAM")
    cuda_ver = os.environ.get("CUDA_VERSION")
    try:
        import torch
        if torch.cuda.is_available():
            if not gpu_name:
                gpu_name = torch.cuda.get_device_name(0)
            if not gpu_vram:
                props = torch.cuda.get_device_properties(0)
                gpu_vram = f"{round(props.total_memory / (1024**3), 1)}GB"
            if not cuda_ver:
                cuda_ver = str(getattr(torch.version, "cuda", "N/A"))
    except Exception:
        pass

    return {
        "gpu_name": gpu_name or "NVIDIA A10G",
        "gpu_vram": gpu_vram or "24GB",
        "cuda_version": cuda_ver or "12.8",
        "video_model": os.environ.get("VIDEO_MODEL", "HunyuanVideo-1.5"),
        "video_model_version": os.environ.get("VIDEO_MODEL_VERSION", "480p_t2v_4step_distilled_fp8"),
        "video_resolution": os.environ.get("VIDEO_RESOLUTION", "848x480"),
        "gpu_max_concurrency": int(os.environ.get("GPU_MAX_CONCURRENCY", "1")),
    }

COMPUTE_CONFIG = detect_compute_config()
MAX_CONCURRENT_JOBS = COMPUTE_CONFIG["gpu_max_concurrency"]

MAX_QUEUE_SIZE = 10



# ===================================================
# KAYAN-GPU-LIFECYCLE-16: Lifecycle & Stage Tracker
# ===================================================
LIFECYCLE_LOCK = threading.Lock()
CURRENT_STAGE = "none"  # "none", "generating", "voice", "lip_sync", "ffmpeg", "file_transfer"
IDLE_TIMEOUT_SECONDS = 600
LAST_ACTIVITY_TIME = time.time()

def set_pipeline_stage(stage: str):
    global CURRENT_STAGE, LAST_ACTIVITY_TIME
    with LIFECYCLE_LOCK:
        CURRENT_STAGE = stage
        LAST_ACTIVITY_TIME = time.time()

def reset_to_idle_if_empty():
    global CURRENT_STAGE, LAST_ACTIVITY_TIME
    with JOBS_LOCK:
        pending = sum(1 for j in JOBS.values() if j["status"] in ("queued", "running"))
    with LIFECYCLE_LOCK:
        if pending == 0:
            CURRENT_STAGE = "none"
            LAST_ACTIVITY_TIME = time.time()

def verify_api_key(x_api_key: str = Header(default=None)):
    """[KAYAN-GPU-SECURITY-12] Shared Secret auth بين Nashash وWorker.
    لا يُطبَع الـ Secret أبداً في أي log أو رسالة خطأ."""
    if not x_api_key or x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized: missing or invalid X-API-Key header")
    return True

app = FastAPI(title="KayanGPU Worker")

# ---- حالة المهام (In-memory job store) ----
JOBS = OrderedDict()
JOBS_LOCK = threading.Lock()
JOB_QUEUE: "Queue[str]" = Queue()
CANCEL_REQUESTED = set()

VALID_STATES = {"queued", "running", "completed", "failed", "cancelled"}


class VideoJobRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=2000)
    seed: Optional[int] = 123
    resolution: Optional[str] = "480p"
    steps: Optional[int] = Field(default=4, ge=1, le=50)
    task: Optional[str] = "t2v"
    reference_image_base64: Optional[str] = None
    negative_prompt: Optional[str] = None
    duration_seconds: Optional[float] = Field(default=5.0, gt=0.0, le=10.0)
    fps: Optional[int] = Field(default=16, ge=8, le=30)
    num_frames: Optional[int] = None
    aspect_ratio: Optional[str] = "16:9"




LIPSYNC_SCRIPT = "/opt/kayangpu/worker/Wav2Lip/run_lipsync.py"
LIPSYNC_PYTHON = "/data/venvs/wav2lip/bin/python"
LIPSYNC_OUTPUT_DIR = "/data/outputs/lipsync"

class LipSyncJobRequest(BaseModel):
    video_path: str = Field(..., min_length=1)
    audio_path: str = Field(..., min_length=1)
def get_gpu_info():
    """GPU Adapter بسيط: اكتشاف تلقائي عبر nvidia-smi فقط، بدون أي قيمة ثابتة."""
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,utilization.gpu",
             "--format=csv,noheader,nounits"],
            timeout=5,
        ).decode().strip()
        name, total, used, util = [x.strip() for x in out.split(",")]
        return {"name": name, "vram_total_mb": int(total), "vram_used_mb": int(used), "utilization_pct": int(util)}
    except Exception as e:
        return {"error": f"GPU not detected: {e}"}


_PIPE = None
_PIPE_LOCK = threading.Lock()

MODEL_PATH = "/data/models/video/hunyuanvideo-1.5/ckpts"
DIT_CKPT = "/data/models/lightx2v/hy1.5_t2v_480p_scaled_fp8_e4m3_lightx2v_4step.safetensors"
OUTPUT_DIR = "/data/outputs"

# ── KAYAN-FACE-ROOT-02: I2V pathway ──
# KAYAN-I2V-STEP-DISTILL: switch to official Step-Distilled checkpoint + dmd2 scheduler.
# Storage: Instance Store (ephemeral) because no EBS was attached.
I2V_CKPT = os.environ.get("KAYAN_I2V_CKPT", "/opt/dlami/nvme/hunyuan/ckpt/transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors")
I2V_TRANSFORMER_NAME = os.environ.get("KAYAN_I2V_TRANSFORMER", "480p_i2v_step_distilled")
I2V_DISTILL_METHOD = "dmd2"
I2V_REF_DIR = "/data/i2v_refs"
_PIPE_I2V = None
_I2V_GEN_KEY = None
_PIPE_I2V_LOCK = threading.Lock()


def _get_pipeline():
    """Warm singleton: يُحمَّل مرة واحدة فقط ويُعاد استخدامه لكل الطلبات التالية."""
    global _PIPE
    with _PIPE_LOCK:
        if _PIPE is None:
            from lightx2v import LightX2VPipeline
            _PIPE = LightX2VPipeline(
                model_path=MODEL_PATH,
                model_cls="hunyuan_video_1.5",
                transformer_model_name="480p_t2v",
                task="t2v",
                dit_original_ckpt=DIT_CKPT,
            )
            _PIPE.enable_offload(
                cpu_offload=True,
                offload_granularity="block",
                text_encoder_offload=True,
                image_encoder_offload=False,
                vae_offload=False,
            )
            _PIPE.create_generator(
                attn_mode="flash_attn2",
                infer_steps=4,
                num_frames=81,
                guidance_scale=1,
                sample_shift=9.0,
                aspect_ratio="16:9",
                fps=16,
                denoising_step_list=[1000, 750, 500, 250],
            )
        return _PIPE


import base64 as _b64

def align_num_frames(n: int, stride: int = 4) -> int:
    return max(stride + 1, n // stride * stride + 1)

def calculate_num_frames(duration_seconds: float, fps: int = 16) -> int:
    return align_num_frames(int(fps * duration_seconds) + 3, 4)

def _save_ref_image(b64: str, job_id: str) -> str:
    if b64[:100].lower().startswith("data:") and "," in b64[:100]:
        b64 = b64.split(",", 1)[1]
    raw = _b64.b64decode(b64, validate=True)
    if len(raw) < 64:
        raise ValueError("reference image too small")
    os.makedirs(I2V_REF_DIR, exist_ok=True)
    p = os.path.join(I2V_REF_DIR, f"{job_id}.img")
    with open(p, "wb") as f:
        f.write(raw)
    return p

def _validate_request(req: "VideoJobRequest"):
    if req.task not in ("t2v", "i2v"):
        raise HTTPException(status_code=400, detail=f"invalid task: {req.task!r}")
    if req.task == "i2v":
        if not req.reference_image_base64:
            raise HTTPException(status_code=400, detail="i2v requires reference_image_base64")
        if not os.path.isfile(I2V_CKPT):
            raise HTTPException(status_code=500, detail=f"i2v checkpoint missing: {I2V_CKPT}")
        if not os.path.isdir(os.path.join(MODEL_PATH, "transformer", I2V_TRANSFORMER_NAME)):
            raise HTTPException(status_code=500, detail="i2v transformer dir missing")
        nf = req.num_frames if req.num_frames is not None else calculate_num_frames(req.duration_seconds or 5.0, req.fps or 16)
        if (nf - 1) % 4 != 0:
            raise HTTPException(status_code=400, detail=f"num_frames={nf} violates (n-1)%4==0")
        if nf < 17 or nf > 121:
            raise HTTPException(status_code=400, detail=f"num_frames={nf} out of supported range [17,121]")
    if not os.path.isfile(DIT_CKPT):
        raise HTTPException(status_code=500, detail=f"t2v checkpoint missing: {DIT_CKPT}")

def _get_i2v_pipeline(req: "VideoJobRequest"):
    # KAYAN-TASK-19-FIX — LightX2VPipeline.create_generator() can be called only
    # ONCE per pipeline instance. When the requested generator config changes,
    # we must drop the current pipeline and build a fresh one.
    # At most one I2V pipeline is kept alive; returning to a previous config
    # rebuilds from scratch (accepted trade-off, matches T2V singleton style).
    global _PIPE_I2V, _I2V_GEN_KEY
    with _PIPE_I2V_LOCK:
        nf = req.num_frames if req.num_frames is not None else calculate_num_frames(req.duration_seconds or 5.0, req.fps or 16)
        key = (int(nf), int(req.steps or 8), int(req.fps or 16), str(req.aspect_ratio or "16:9"))
        if _PIPE_I2V is not None and _I2V_GEN_KEY != key:
            _PIPE_I2V = None
            _I2V_GEN_KEY = None
            try:
                import torch
                torch.cuda.empty_cache()
            except Exception:
                pass
        if _PIPE_I2V is None:
            from lightx2v import LightX2VPipeline
            _PIPE_I2V = LightX2VPipeline(
                model_path=MODEL_PATH,
                model_cls="hunyuan_video_1.5",
                transformer_model_name=I2V_TRANSFORMER_NAME,
                task="i2v",
                dit_original_ckpt=I2V_CKPT,
                distill_method=I2V_DISTILL_METHOD,
            )
            _PIPE_I2V.enable_offload(
                cpu_offload=True,
                offload_granularity="block",
                text_encoder_offload=True,
                image_encoder_offload=True,
                vae_offload=True,
            )
            _PIPE_I2V.create_generator(
                attn_mode="flash_attn2",
                infer_steps=key[1],
                num_frames=key[0],
                guidance_scale=1,
                sample_shift=7.0,   # KAYAN-I2V-STEP-DISTILL: official flow shift for Step-Distilled
                aspect_ratio=key[3],
                fps=key[2],
                denoising_step_list=[1000, 875, 750, 625, 500, 375, 250, 125],
            )
            _I2V_GEN_KEY = key
    return _PIPE_I2V

def run_generation_job(job_id: str, req: VideoJobRequest):
    """
    [KayanGPU] KAYAN-WORKER-09: ربط حقيقي بـ LightX2V + HunyuanVideo-1.5.
    لا Mock/Fake/Placeholder - ناتج MP4 حقيقي فقط أو فشل صريح.
    """
    with JOBS_LOCK:
        JOBS[job_id]["status"] = "running"
        JOBS[job_id]["started_at"] = datetime.utcnow().isoformat()
        set_pipeline_stage("generating")

    if job_id in CANCEL_REQUESTED:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "cancelled"
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()
        CANCEL_REQUESTED.discard(job_id)
        return

    try:
        output_path = f"{OUTPUT_DIR}/job_{job_id}.mp4"
        if req.task == "i2v":
            ref_path = _save_ref_image(req.reference_image_base64, job_id)
            pipe = _get_i2v_pipeline(req)
            _kp = (req.negative_prompt or "").strip()
            pipe.generate(
                seed=req.seed or 123,
                prompt=req.prompt,
                negative_prompt=_kp if _kp else None,
                image_path=ref_path,
                save_result_path=output_path,
            )
        else:
            pipe = _get_pipeline()
            _kp = (req.negative_prompt or "").strip()
            pipe.generate(
                seed=req.seed or 123,
                prompt=req.prompt,
                negative_prompt=_kp if _kp else None,
                save_result_path=output_path,
            )

        if job_id in CANCEL_REQUESTED:
            with JOBS_LOCK:
                JOBS[job_id]["status"] = "cancelled"
                JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()
            CANCEL_REQUESTED.discard(job_id)
            return

        with JOBS_LOCK:
            JOBS[job_id]["status"] = "completed"
            JOBS[job_id]["output_path"] = output_path
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()

    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "failed"
            JOBS[job_id]["error"] = f"{type(e).__name__}: {e}"
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()


def run_lipsync_job(job_id: str, req: "LipSyncJobRequest"):
    with JOBS_LOCK:
        JOBS[job_id]["status"] = "running"
        JOBS[job_id]["started_at"] = datetime.utcnow().isoformat()
        set_pipeline_stage("lip_sync")
    try:
        vid = req.video_path
        aud = req.audio_path
        if not os.path.isfile(vid) or os.path.getsize(vid) == 0:
            raise RuntimeError(f"video_path missing/empty: {vid}")
        if not os.path.isfile(aud) or os.path.getsize(aud) == 0:
            raise RuntimeError(f"audio_path missing/empty: {aud}")
        os.makedirs(LIPSYNC_OUTPUT_DIR, exist_ok=True)
        out_path = f"{LIPSYNC_OUTPUT_DIR}/lipsync_{job_id}.mp4"
        cmd = [LIPSYNC_PYTHON, LIPSYNC_SCRIPT, vid, aud, out_path]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
        if proc.returncode != 0:
            combined = (proc.stdout or "") + "\n" + (proc.stderr or "")
            # Structured SKIP: video has no human face — pass through original video.
            if "KAYAN_FACE_NOT_DETECTED" in combined:
                with JOBS_LOCK:
                    JOBS[job_id]["status"] = "completed"
                    JOBS[job_id]["output_path"] = vid            # original video as-is
                    JOBS[job_id]["skipped"] = True
                    JOBS[job_id]["reason"] = "no_face_in_video"
                    JOBS[job_id]["note"] = "lipsync skipped: video contains no human face"
                    JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()
                return
            raise RuntimeError(
                f"lipsync runner exit {proc.returncode}: "
                f"stdout_tail={proc.stdout[-400:]!r} stderr_tail={proc.stderr[-400:]!r}"
            )
        if not os.path.isfile(out_path) or os.path.getsize(out_path) == 0:
            raise RuntimeError(f"lipsync output missing: {out_path}")
        if os.path.abspath(out_path) == os.path.abspath(vid):
            raise RuntimeError("lipsync produced same path as input")
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "completed"
            JOBS[job_id]["output_path"] = out_path
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()
    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "failed"
            JOBS[job_id]["error"] = f"{type(e).__name__}: {e}"
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()


def worker_loop():
    """معالج تسلسلي واحد فقط (GPU_MAX_CONCURRENCY=1) — يطابق تصميم ARCH-00."""
    while True:
        try:
            job_id = JOB_QUEUE.get(timeout=1)
        except Empty:
            continue
        with JOBS_LOCK:
            req_data = JOBS[job_id]["_request"]
            job_kind = JOBS[job_id].get("_kind", "video")
        if job_kind == "lipsync":
            run_lipsync_job(job_id, req_data)
        else:
            run_generation_job(job_id, req_data)
        reset_to_idle_if_empty()


threading.Thread(target=worker_loop, daemon=True).start()


def check_cuda_available():
    """فحص خفيف: قراءة حالة _PIPE إن كانت محمَّلة، وإلا فحص عبر nvidia-smi فقط (بدون استيراد torch الثقيل إن لم يكن مطلوباً)."""
    try:
        import torch
        return torch.cuda.is_available()
    except Exception:
        return None


def check_model_available():
    """فحص وجود ملفات النموذج على القرص فقط - لا تحميل فعلي."""
    return (
        os.path.isfile(DIT_CKPT) and os.path.isdir(MODEL_PATH)
        and os.path.isfile(I2V_CKPT)
        and os.path.isdir(os.path.join(MODEL_PATH, "transformer", I2V_TRANSFORMER_NAME))
    )


def check_storage_available():
    """فحص خفيف لمساحة القرص المتاحة على /data/outputs."""
    try:
        st = os.statvfs(OUTPUT_DIR)
        free_gb = (st.f_bavail * st.f_frsize) / (1024**3)
        return {"available": free_gb > 1.0, "free_gb": round(free_gb, 2)}
    except Exception as e:
        return {"available": False, "error": str(e)}


@app.get("/health")
def health():
    gpu = get_gpu_info()
    gpu_available = "error" not in gpu
    cuda_available = check_cuda_available()
    model_available = check_model_available()
    storage = check_storage_available()

    with JOBS_LOCK:
        queued = sum(1 for j in JOBS.values() if j["status"] == "queued")
        running = sum(1 for j in JOBS.values() if j["status"] == "running")
        completed = sum(1 for j in JOBS.values() if j["status"] == "completed")
        failed = sum(1 for j in JOBS.values() if j["status"] == "failed")

    overall_healthy = gpu_available and bool(cuda_available) and model_available and storage["available"]

    return {
        "status": "healthy" if overall_healthy else "degraded",
        "checks": {
            "worker_running": True,
            "gpu_available": gpu_available,
            "cuda_available": cuda_available,
            "model_available": model_available,
            "storage_available": storage["available"],
        },
        "gpu": gpu,
        "storage": storage,
        "compute": detect_compute_config(),
        "model": {"name": COMPUTE_CONFIG["video_model"], "variant": COMPUTE_CONFIG["video_model_version"]},
        "queue": {
            "queued": queued,
            "running": running,
            "completed_total": completed,
            "failed_total": failed,
            "max_concurrency": COMPUTE_CONFIG["gpu_max_concurrency"],
        },
    }


@app.get("/metrics")
def metrics():
    """[KAYAN-GPU-MONITOR-15] مقاييس تفصيلية إضافية - نفس مبدأ health، فحص خفيف فقط."""
    import psutil
    gpu = get_gpu_info()
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage(OUTPUT_DIR)
    swap = psutil.swap_memory()

    with JOBS_LOCK:
        jobs_summary = [
            {"job_id": j["job_id"], "status": j["status"],
             "created_at": j["created_at"], "finished_at": j.get("finished_at")}
            for j in JOBS.values()
        ]

    return {
        "gpu": gpu,
        "ram": {"total_mb": vm.total // (1024**2), "used_mb": vm.used // (1024**2), "percent": vm.percent},
        "swap": {"total_mb": swap.total // (1024**2), "used_mb": swap.used // (1024**2)},
        "disk": {"total_gb": round(disk.total / (1024**3), 1), "used_gb": round(disk.used / (1024**3), 1)},
        "jobs": jobs_summary,
    }


@app.post("/jobs/video")
def create_job(req: VideoJobRequest, _auth: bool = Depends(verify_api_key)):
    _validate_request(req)
    with JOBS_LOCK:
        pending = sum(1 for j in JOBS.values() if j["status"] in ("queued", "running"))
    if pending >= MAX_QUEUE_SIZE:
        raise HTTPException(status_code=429, detail=f"Queue full (max {MAX_QUEUE_SIZE} pending jobs)")
    job_id = str(uuid.uuid4())
    with JOBS_LOCK:
        JOBS[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "created_at": datetime.utcnow().isoformat(),
            "started_at": None,
            "finished_at": None,
            "output_path": None,
            "error": None,
            "_request": req,
            "_kind": "video",
        }
    JOB_QUEUE.put(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
def get_job(job_id: str, _auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        return {k: v for k, v in job.items() if not k.startswith("_")}


@app.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: str, _auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        if job["status"] == "queued":
            job["status"] = "cancelled"
            job["finished_at"] = datetime.utcnow().isoformat()
            CANCEL_REQUESTED.add(job_id)
            return {"job_id": job_id, "status": "cancelled"}
        elif job["status"] == "running":
            CANCEL_REQUESTED.add(job_id)
            return {"job_id": job_id, "status": "running", "note": "cancel requested, will apply if not too late"}
        else:
            return {"job_id": job_id, "status": job["status"], "note": "already finished, cannot cancel"}


@app.post("/jobs/lipsync")
def create_lipsync_job(req: LipSyncJobRequest, _auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        pending = sum(1 for j in JOBS.values() if j["status"] in ("queued", "running"))
    if pending >= MAX_QUEUE_SIZE:
        raise HTTPException(status_code=429, detail=f"Queue full (max {MAX_QUEUE_SIZE} pending jobs)")
    job_id = str(uuid.uuid4())
    with JOBS_LOCK:
        JOBS[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "created_at": datetime.utcnow().isoformat(),
            "started_at": None,
            "finished_at": None,
            "output_path": None,
            "error": None,
            "_request": req,
            "_kind": "lipsync",
            "skipped": False,
            "reason": None,
        }
    JOB_QUEUE.put(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.get("/lifecycle/status")
def get_lifecycle_status(_auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        queued = sum(1 for j in JOBS.values() if j["status"] == "queued")
        active = sum(1 for j in JOBS.values() if j["status"] == "running")
    with LIFECYCLE_LOCK:
        stage = CURRENT_STAGE
        last_act = LAST_ACTIVITY_TIME
    is_safe = (queued == 0 and active == 0 and stage == "none")
    now = time.time()
    idle_sec = round(now - last_act, 1) if is_safe else 0.0
    stop_rec = is_safe and (idle_sec >= IDLE_TIMEOUT_SECONDS)
    return {
        "can_stop": is_safe,
        "active_jobs": active,
        "queued_jobs": queued,
        "current_stage": stage,
        "idle_seconds": idle_sec,
        "idle_timeout_seconds": IDLE_TIMEOUT_SECONDS,
        "stop_recommended": stop_rec
    }


class StageUpdateRequest(BaseModel):
    stage: str

@app.post("/lifecycle/stage")
def update_pipeline_stage(req: StageUpdateRequest, _auth: bool = Depends(verify_api_key)):
    allowed = {"none", "generating", "voice", "lip_sync", "ffmpeg", "file_transfer"}
    if req.stage not in allowed:
        raise HTTPException(status_code=400, detail=f"Invalid stage. Allowed: {allowed}")
    set_pipeline_stage(req.stage)
    if req.stage == "none":
        reset_to_idle_if_empty()
    with LIFECYCLE_LOCK:
        current = CURRENT_STAGE
    return {"current_stage": current, "status": "updated"}


@app.get("/compute/config")
def get_compute_config():
    """Returns dynamic compute and hardware capabilities for Nashash controller."""
    return detect_compute_config()
