# KayanGPU — التعديلات اليدوية الحرجة (Patches)

هذه التعديلات ضرورية لعمل LightX2V على هذه البيئة (16GB RAM + Swap).
بدونها، النظام يفشل أو يتعلق لساعات. طبقها بالترتيب بعد pip install lightx2v.

## Patch 1: nbhd_attn.py - التقاط OSError بجانب ImportError

الملف: {venv}/lib/python3.12/site-packages/lightx2v/common/ops/attn/nbhd_attn.py

المشكلة: import flashinfer يفشل أحياناً بـ OSError (تعارض ABI بين flashinfer وإصدار PyTorch)، لكن الكود الأصلي يلتقط ImportError فقط، فينهار البرنامج بالكامل بدل التعامل مع الفشل بأمان.

السطر الأصلي:
try:
    import flashinfer
except ImportError:
    flashinfer = None

التعديل:
try:
    import flashinfer
except (ImportError, OSError) as e:
    print(f"[KayanGPU] flashinfer غير متاح بسبب تعارض مكتبات، سيتم المتابعة بدونه: {e}")
    flashinfer = None

---

## Patch 2: utils.py - تعطيل pin_memory

الملف: {venv}/lib/python3.12/site-packages/lightx2v/common/ops/utils.py (حوالي السطر 90، داخل دالة create_pin_tensor)

المشكلة: torch.empty(..., pin_memory=True, ...) يتعلق لدقائق طويلة (idle، بدون أي تقدم) على أنظمة تعتمد جزئياً على Swap.

السطر الأصلي:
pin_tensor = torch.empty(tensor.shape, pin_memory=True, dtype=dtype)

التعديل:
pin_tensor = torch.empty(tensor.shape, pin_memory=False, dtype=dtype)

أمر تطبيق سريع:
sed -i 's/pin_memory=True/pin_memory=False/' path/to/utils.py

---

## Patch 3: torchaudio غير متوافق (إزالة)

المشكلة: بعد ترقية PyTorch إلى 2.8.0+cu128، torchaudio يفشل بـ undefined symbol: torch_library_impl عند الاستيراد.

الحل:
pip uninstall -y torchaudio

---

## Patch 4: سكربت التوليد

- attn_mode يجب أن يكون "flash_attn2" - القيم "torch" أو "sage_attn2" (بدون SageAttention منفصل) غير مسجلة في ATTN_WEIGHT_REGISTER وستفشل بـ KeyError.
- لا تُمرَّر negative_prompt إلى pipe.generate() - HunyuanVideo15Runner في وضع t2v لا يدعمها.

## ترتيب التطبيق الموصى به
1. pip install lightx2v
2. طبق Patch 1 و Patch 2 فوراً
3. pip uninstall torchaudio (Patch 3)
4. اكتب سكربت التوليد مع مراعاة Patch 4
5. شغّل verify.sh للتأكد
