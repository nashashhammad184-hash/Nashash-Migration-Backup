# KayanGPU - دليل إعادة البناء الكامل

## البيئة المرجعية المختبرة
- OS: Ubuntu 24.04.4 LTS
- GPU: NVIDIA A10G 24GB VRAM
- CUDA: 13.2
- Python: 3.12.3
- PyTorch: 2.8.0+cu128
- LightX2V: 0.5.0
- flash-attn: 2.8.3.post1
- HunyuanVideo-1.5: commit 60783e7

## خطوات إعادة البناء

### 1. تجهيز خادم جديد
استأجر EC2 مع GPU (A10G أو أحدث)، Ubuntu 24.04، 250GB+ قرص.

### 2. استنساخ هذا المستودع
git clone https://github.com/nashashhammad184-hash/KayanGPU.git
cd KayanGPU

### 3. تشغيل الإعداد الأساسي
chmod +x setup.sh verify.sh
./setup.sh

### 4. تطبيق الـPatches
راجع docs/PATCHES.md وطبق التعديلات يدوياً.

### 5. تنزيل النماذج
راجع MODEL_MANIFEST.md للتفاصيل والأوامر الكاملة.

### 6. نسخ كود Worker
انسخ worker/main.py إلى /opt/kayangpu/api/main.py

### 7. إعداد Secret
mkdir -p /opt/kayangpu/api
python3 -c "import secrets; print('KAYANGPU_API_KEY=' + secrets.token_hex(32))" > /opt/kayangpu/api/.env
chmod 600 /opt/kayangpu/api/.env

### 8. تثبيت systemd service
sudo cp systemd/kayangpu-worker.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable kayangpu-worker
sudo systemctl start kayangpu-worker

### 9. التحقق النهائي
./verify.sh
curl -s http://127.0.0.1:8080/health
