#!/usr/bin/env bash
# KayanGPU - Setup Script (KAYAN-GPU-BACKUP-14)
# متطلبات: Ubuntu 24.04, NVIDIA GPU (A10G مختبر، Ampere+ متوقع يعمل)
set -euo pipefail

echo "=== KayanGPU Setup ==="

echo "--- 1) فحص GPU ---"
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader

echo "--- 2) إنشاء بنية /data ---"
sudo mkdir -p /data/models /data/projects /data/outputs /data/cache /data/logs
sudo chown -R $USER:$USER /data

echo "--- 3) Swap دائم (ضروري لتحميل النماذج على RAM محدود) ---"
if [ ! -f /swapfile ]; then
  sudo fallocate -l 40G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile
fi
if [ ! -f /swapfile2 ]; then
  sudo fallocate -l 40G /swapfile2 && sudo chmod 600 /swapfile2 && sudo mkswap /swapfile2
fi
sudo swapon /swapfile 2>/dev/null || true
sudo swapon /swapfile2 2>/dev/null || true
grep -q "/swapfile " /etc/fstab || echo "/swapfile none swap sw 0 0" | sudo tee -a /etc/fstab
grep -q "/swapfile2 " /etc/fstab || echo "/swapfile2 none swap sw 0 0" | sudo tee -a /etc/fstab

echo "--- 4) حزم النظام ---"
sudo apt update -y
sudo apt install -y ffmpeg git git-lfs python3-venv

echo "--- 5) venv ---"
python3 -m venv /data/lightx2v_test/venv
source /data/lightx2v_test/venv/bin/activate
pip install --upgrade pip

echo "--- 6) PyTorch 2.8.0+cu128 (إلزامي - يتطلبه comfy_kitchen عبر lightx2v) ---"
pip install torch==2.8.0 torchvision --index-url https://download.pytorch.org/whl/cu128

echo "--- 7) LightX2V ---"
pip install "git+https://github.com/ModelTC/LightX2V.git"

echo "--- 8) flash-attn (يتطلب تجميع، قد يأخذ 15-30 دقيقة) ---"
pip install flash-attn --no-build-isolation

echo "--- 9) إزالة torchaudio (غير متوافق ABI مع torch 2.8.0+cu128 هنا وغير مطلوب) ---"
pip uninstall -y torchaudio 2>/dev/null || true

echo "--- 10) استنساخ HunyuanVideo-1.5 (للبنية فقط، بدون أوزان) ---"
mkdir -p /opt/kayangpu/worker
git clone https://github.com/Tencent-Hunyuan/HunyuanVideo-1.5.git /opt/kayangpu/worker/HunyuanVideo-1.5 2>/dev/null || echo "موجود مسبقاً"

echo ""
echo "=== ⚠️ خطوة يدوية مطلوبة: تطبيق الـpatches الإلزامية ==="
echo "راجع docs/PATCHES.md لتطبيق تعديلين حرجين:"
echo "  1) lightx2v/common/ops/attn/nbhd_attn.py - توسيع except لـ(ImportError, OSError)"
echo "  2) lightx2v/common/ops/utils.py - pin_memory=True → False"
echo ""
echo "=== ⚠️ تنزيل النماذج (~60GB) - راجع MODEL_MANIFEST.md، غير مُشمَل هنا تلقائياً ==="
echo ""
echo "[DONE] Setup الأساسي اكتمل. راجع RESTORE.md للخطوات المتبقية."
