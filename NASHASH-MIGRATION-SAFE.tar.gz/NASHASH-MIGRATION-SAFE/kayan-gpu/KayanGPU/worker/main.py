"""
KayanGPU Worker API
- GET  /health
- POST /jobs/video
- GET  /jobs/{job_id}
- POST /jobs/{job_id}/cancel
"""
import subprocess
import threading
import time
import uuid
from collections import OrderedDict
from datetime import datetime
from queue import Queue, Empty
from typing import Optional

import os
from fastapi import FastAPI, HTTPException, Header, Depends
from pydantic import BaseModel, Field

API_KEY = os.environ.get("KAYANGPU_API_KEY")
if not API_KEY:
    raise RuntimeError("KAYANGPU_API_KEY environment variable is required and not set")

MAX_PROMPT_LENGTH = 2000
MAX_CONCURRENT_JOBS = 1
MAX_QUEUE_SIZE = 10


def verify_api_key(x_api_key: str = Header(default=None)):
    """[KAYAN-GPU-SECURITY-12] Shared Secret auth بين Nashash وWorker.
    لا يُطبَع الـ Secret أبداً في أي log أو رسالة خطأ."""
    if not x_api_key or x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized: missing or invalid X-API-Key header")
    return True

app = FastAPI(title="KayanGPU Worker")

# ---- حالة المهام (In-memory job store) ----
JOBS = OrderedDict()
JOBS_LOCK = threading.Lock()
JOB_QUEUE: "Queue[str]" = Queue()
CANCEL_REQUESTED = set()

VALID_STATES = {"queued", "running", "completed", "failed", "cancelled"}


class VideoJobRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=2000)
    seed: Optional[int] = 123
    resolution: Optional[str] = "480p"
    steps: Optional[int] = Field(default=4, ge=1, le=50)


def get_gpu_info():
    """GPU Adapter بسيط: اكتشاف تلقائي عبر nvidia-smi فقط، بدون أي قيمة ثابتة."""
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,utilization.gpu",
             "--format=csv,noheader,nounits"],
            timeout=5,
        ).decode().strip()
        name, total, used, util = [x.strip() for x in out.split(",")]
        return {"name": name, "vram_total_mb": int(total), "vram_used_mb": int(used), "utilization_pct": int(util)}
    except Exception as e:
        return {"error": f"GPU not detected: {e}"}


_PIPE = None
_PIPE_LOCK = threading.Lock()

MODEL_PATH = "/data/models/video/hunyuanvideo-1.5/ckpts"
DIT_CKPT = "/data/models/lightx2v/hy1.5_t2v_480p_scaled_fp8_e4m3_lightx2v_4step.safetensors"
OUTPUT_DIR = "/data/outputs"


def _get_pipeline():
    """Warm singleton: يُحمَّل مرة واحدة فقط ويُعاد استخدامه لكل الطلبات التالية."""
    global _PIPE
    with _PIPE_LOCK:
        if _PIPE is None:
            from lightx2v import LightX2VPipeline
            _PIPE = LightX2VPipeline(
                model_path=MODEL_PATH,
                model_cls="hunyuan_video_1.5",
                transformer_model_name="480p_t2v",
                task="t2v",
                dit_original_ckpt=DIT_CKPT,
            )
            _PIPE.enable_offload(
                cpu_offload=True,
                offload_granularity="block",
                text_encoder_offload=True,
                image_encoder_offload=False,
                vae_offload=False,
            )
            _PIPE.create_generator(
                attn_mode="flash_attn2",
                infer_steps=4,
                num_frames=81,
                guidance_scale=1,
                sample_shift=9.0,
                aspect_ratio="16:9",
                fps=16,
                denoising_step_list=[1000, 750, 500, 250],
            )
        return _PIPE


def run_generation_job(job_id: str, req: VideoJobRequest):
    """
    [KayanGPU] KAYAN-WORKER-09: ربط حقيقي بـ LightX2V + HunyuanVideo-1.5.
    لا Mock/Fake/Placeholder - ناتج MP4 حقيقي فقط أو فشل صريح.
    """
    with JOBS_LOCK:
        JOBS[job_id]["status"] = "running"
        JOBS[job_id]["started_at"] = datetime.utcnow().isoformat()

    if job_id in CANCEL_REQUESTED:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "cancelled"
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()
        CANCEL_REQUESTED.discard(job_id)
        return

    try:
        pipe = _get_pipeline()
        output_path = f"{OUTPUT_DIR}/job_{job_id}.mp4"

        pipe.generate(
            seed=req.seed or 123,
            prompt=req.prompt,
            save_result_path=output_path,
        )

        if job_id in CANCEL_REQUESTED:
            with JOBS_LOCK:
                JOBS[job_id]["status"] = "cancelled"
                JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()
            CANCEL_REQUESTED.discard(job_id)
            return

        with JOBS_LOCK:
            JOBS[job_id]["status"] = "completed"
            JOBS[job_id]["output_path"] = output_path
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()

    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "failed"
            JOBS[job_id]["error"] = f"{type(e).__name__}: {e}"
            JOBS[job_id]["finished_at"] = datetime.utcnow().isoformat()


def worker_loop():
    """معالج تسلسلي واحد فقط (GPU_MAX_CONCURRENCY=1) — يطابق تصميم ARCH-00."""
    while True:
        try:
            job_id = JOB_QUEUE.get(timeout=1)
        except Empty:
            continue
        with JOBS_LOCK:
            req_data = JOBS[job_id]["_request"]
        run_generation_job(job_id, req_data)


threading.Thread(target=worker_loop, daemon=True).start()


@app.get("/health")
def health():
    gpu = get_gpu_info()
    with JOBS_LOCK:
        queued = sum(1 for j in JOBS.values() if j["status"] == "queued")
        running = sum(1 for j in JOBS.values() if j["status"] == "running")
    return {
        "status": "healthy",
        "gpu": gpu,
        "model": {"name": "HunyuanVideo-1.5", "variant": "480p_t2v_4step_distilled_fp8"},
        "queue": {"queued": queued, "running": running, "max_concurrency": 1},
    }


@app.post("/jobs/video")
def create_job(req: VideoJobRequest, _auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        pending = sum(1 for j in JOBS.values() if j["status"] in ("queued", "running"))
    if pending >= MAX_QUEUE_SIZE:
        raise HTTPException(status_code=429, detail=f"Queue full (max {MAX_QUEUE_SIZE} pending jobs)")
    job_id = str(uuid.uuid4())
    with JOBS_LOCK:
        JOBS[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "created_at": datetime.utcnow().isoformat(),
            "started_at": None,
            "finished_at": None,
            "output_path": None,
            "error": None,
            "_request": req,
        }
    JOB_QUEUE.put(job_id)
    return {"job_id": job_id, "status": "queued"}


@app.get("/jobs/{job_id}")
def get_job(job_id: str, _auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        return {k: v for k, v in job.items() if not k.startswith("_")}


@app.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: str, _auth: bool = Depends(verify_api_key)):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        if job["status"] == "queued":
            job["status"] = "cancelled"
            job["finished_at"] = datetime.utcnow().isoformat()
            CANCEL_REQUESTED.add(job_id)
            return {"job_id": job_id, "status": "cancelled"}
        elif job["status"] == "running":
            CANCEL_REQUESTED.add(job_id)
            return {"job_id": job_id, "status": "running", "note": "cancel requested, will apply if not too late"}
        else:
            return {"job_id": job_id, "status": job["status"], "note": "already finished, cannot cancel"}
