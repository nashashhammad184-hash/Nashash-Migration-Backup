# KayanGPU — Model Manifest

⚠️ لا تُرفَع أي من هذه الأوزان إلى Git. هذا الملف توثيق فقط لمصادر التنزيل والأحجام الفعلية.

| النموذج | الحجم الفعلي | المصدر | الغرض |
|---|---|---|---|
| HunyuanVideo-1.5 DiT (480p_t2v) | 32GB | tencent/HunyuanVideo-1.5 (HuggingFace) - transformer/480p_t2v/diffusion_pytorch_model.safetensors | البنية الأصلية المرجعية (غير مُستخدَمة مباشرة في التوليد؛ أوزانها تُستبدَل بالنموذج المُقطَّر أدناه) |
| VAE | 4.7GB | tencent/HunyuanVideo-1.5 - vae/diffusion_pytorch_model.safetensors | فك الترميز البصري |
| Text Encoder (Qwen2.5-VL-7B) | ~15GB (5 shards) | tencent/HunyuanVideo-1.5 - text_encoder/llm/ | ترميز النص/الوصف |
| **LightX2V 4-Step Distilled FP8** | **8.85GB** | lightx2v/Hy1.5-Distill-Models (HuggingFace) - hy1.5_t2v_480p_scaled_fp8_e4m3_lightx2v_4step.safetensors | **النموذج الفعلي المُستخدَم في الإنتاج** (أخف 4× من الأصلي، 4 خطوات استنتاج بدل 20+) |

## ملاحظة معمارية مهمة
النموذج الأصلي (32GB) **مطلوب فعلياً** لأن LightX2V يحتاج بنية/config من `model_path` الأصلي (config.json، vae، text_encoder)، حتى مع استبدال أوزان الـDiT بالنسخة المُقطَّرة عبر `dit_original_ckpt`. **لا تُحذَف** أي من الملفات الأصلية.

## إجمالي المساحة المطلوبة لإعادة البناء
~60GB (DiT الأصلي 32GB + VAE 4.7GB + Text Encoder ~15GB + النموذج المُقطَّر 8.85GB)

## ممنوع صراحة
لا تُنزَّل أي نسخة من HunyuanVideo الأصلي بصيغة `mp_rank_00_model_states.pt` (تنسيق Megatron القديم) — هذا نموذج مختلف تماماً وأضخم (37GB+)، سبَّب مشكلة حقيقية سابقاً (KAYAN-RECOVERY-00) ولا علاقة له بالمسار المعتمد هنا.
