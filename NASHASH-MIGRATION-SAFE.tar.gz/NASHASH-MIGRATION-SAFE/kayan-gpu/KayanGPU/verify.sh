#!/usr/bin/env bash
# KayanGPU - Verification Script (KAYAN-GPU-BACKUP-14)
set -uo pipefail

STATUS=0
check() {
  if eval "$2"; then echo "[PASS] $1"; else echo "[FAIL] $1"; STATUS=1; fi
}

echo "=== KayanGPU Verification ==="

check "GPU detected" "nvidia-smi --query-gpu=name --format=csv,noheader | grep -qi nvidia"
check "venv exists" "[ -f /data/lightx2v_test/venv/bin/python3 ]"
check "torch 2.8.0 installed" "/data/lightx2v_test/venv/bin/python3 -c 'import torch; exit(0 if torch.__version__.startswith(\"2.8.0\") else 1)'"
check "CUDA available" "/data/lightx2v_test/venv/bin/python3 -c 'import torch; exit(0 if torch.cuda.is_available() else 1)'"
check "lightx2v installed" "/data/lightx2v_test/venv/bin/pip show lightx2v > /dev/null 2>&1"
check "flash-attn installed" "/data/lightx2v_test/venv/bin/pip show flash-attn > /dev/null 2>&1"
check "HunyuanVideo repo exists" "[ -d /opt/kayangpu/worker/HunyuanVideo-1.5 ]"
check "pin_memory patch applied" "grep -q 'pin_memory=False' /data/lightx2v_test/venv/lib/python3.12/site-packages/lightx2v/common/ops/utils.py"
check "flashinfer patch applied" "grep -q 'ImportError, OSError' /data/lightx2v_test/venv/lib/python3.12/site-packages/lightx2v/common/ops/attn/nbhd_attn.py"
check "DiT model present (32GB)" "[ -f /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_t2v/diffusion_pytorch_model.safetensors ]"
check "Distilled FP8 model present" "[ -f /data/models/lightx2v/hy1.5_t2v_480p_scaled_fp8_e4m3_lightx2v_4step.safetensors ]"
check "Worker main.py exists" "[ -f /opt/kayangpu/api/main.py ]"
check "Worker .env exists (secret)" "[ -f /opt/kayangpu/api/.env ]"
check "systemd service file exists" "[ -f /etc/systemd/system/kayangpu-worker.service ]"
check "systemd service active" "systemctl is-active --quiet kayangpu-worker"
check "Worker health endpoint responds" "curl -sf http://127.0.0.1:8080/health > /dev/null"
check "/data structure correct" "[ -d /data/models ] && [ -d /data/outputs ] && [ -d /data/cache ] && [ -d /data/logs ]"
check "Swap configured (79GB+)" "[ \$(free -m | awk 'NR==3{print \$2}') -gt 70000 ]"

echo ""
if [ $STATUS -eq 0 ]; then
  echo "=== OVERALL: PASS ==="
else
  echo "=== OVERALL: FAIL (راجع البنود أعلاه) ==="
fi
exit $STATUS
