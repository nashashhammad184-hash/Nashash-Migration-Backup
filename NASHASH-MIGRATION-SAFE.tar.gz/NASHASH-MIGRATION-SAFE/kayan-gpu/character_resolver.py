class CharacterResolver:
    @staticmethod
    def build_shot_prompt(character: dict, action_prompt: str) -> str:
        if not character:
            return action_prompt
        
        char_id = character.get("id", "unknown")
        name = character.get("name", "Unnamed")
        appearance = character.get("appearance_reference", "Standard appearance")
        
        identity_profile = f"[Character ID: {char_id} | Name: {name} | Appearance: {appearance}]"
        return f"{identity_profile} Action: {action_prompt}"
