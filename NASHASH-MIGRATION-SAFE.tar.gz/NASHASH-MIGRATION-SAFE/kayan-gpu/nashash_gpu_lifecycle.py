"""
KayanGPU Lifecycle Orchestrator for Nashash Controller
Implements KAYAN-GPU-LIFECYCLE-16
Strict Rule: STOP ONLY (Never Terminate). Respects protected stages.
"""

import time
import requests
import boto3
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("KayanLifecycle")

INSTANCE_ID = "i-0e326a2b66deeaa0c"
REGION = "eu-north-1"
WORKER_PORT = 8080

def get_ec2_client():
    return boto3.client("ec2", region_name=REGION)

def get_instance_state():
    ec2 = get_ec2_client()
    res = ec2.describe_instances(InstanceIds=[INSTANCE_ID])
    return res["Reservations"][0]["Instances"][0]["State"]["Name"]

def get_instance_ip():
    ec2 = get_ec2_client()
    res = ec2.describe_instances(InstanceIds=[INSTANCE_ID])
    inst = res["Reservations"][0]["Instances"][0]
    return inst.get("PublicIpAddress") or inst.get("PrivateIpAddress")

def start_gpu_and_wait(timeout=300):
    """السيناريو 3: GPU Starting"""
    ec2 = get_ec2_client()
    state = get_instance_state()
    if state == "running":
        logger.info(f"Instance {INSTANCE_ID} is already running.")
        return get_instance_ip()

    logger.info(f"Initiating ec2.start_instances for {INSTANCE_ID} (Current state: {state})...")
    ec2.start_instances(InstanceIds=[INSTANCE_ID])

    start_time = time.time()
    while time.time() - start_time < timeout:
        state = get_instance_state()
        logger.info(f"Instance starting... state: {state}")
        if state == "running":
            ip = get_instance_ip()
            logger.info(f"Instance is running. IP: {ip}")
            return ip
        time.sleep(5)
    raise TimeoutError("Timed out waiting for GPU instance to start.")

def wait_for_worker_ready(ip, api_key, timeout=300):
    """السيناريو 4: Worker Ready"""
    url = f"http://{ip}:{WORKER_PORT}/health"
    headers = {"X-API-Key": api_key}
    start_time = time.time()

    logger.info(f"Polling worker health at {url}...")
    while time.time() - start_time < timeout:
        try:
            r = requests.get(url, headers=headers, timeout=5)
            if r.status_code == 200:
                data = r.json()
                checks = data.get("checks", {})
                if checks.get("worker_running") and checks.get("model_available"):
                    logger.info("Worker is HEALTHY and Model is AVAILABLE.")
                    return True
        except requests.exceptions.RequestException:
            pass
        time.sleep(5)
    raise TimeoutError("Timed out waiting for Worker API to be healthy.")

def verify_safe_to_stop(ip, api_key):
    """التحقق الصارم من عدم وجود مهام أو مراحل نشطة"""
    url = f"http://{ip}:{WORKER_PORT}/lifecycle/status"
    headers = {"X-API-Key": api_key}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        r.raise_for_status()
        status = r.json()
    except Exception as e:
        logger.error(f"Cannot query lifecycle status: {e}. Refusing to stop for safety.")
        return False

    can_stop = status.get("can_stop", False)
    active = status.get("active_jobs", 1)
    queued = status.get("queued_jobs", 1)
    stage = status.get("current_stage", "unknown")

    if not can_stop or active > 0 or queued > 0 or stage != "none":
        logger.warning(
            f"STOP REFUSED: Worker active! Stage={stage}, Active={active}, Queued={queued}"
        )
        return False

    return True

def stop_gpu_safely(ip, api_key):
    """
    السيناريو 8: إيقاف الخادم (STOP حصراً - ممنوع Terminate)
    """
    if not verify_safe_to_stop(ip, api_key):
        logger.error("Safety check failed. Aborting stop.")
        return False

    logger.info(f"All safety checks passed. Issuing ec2.stop_instances on {INSTANCE_ID}...")
    ec2 = get_ec2_client()
    ec2.stop_instances(InstanceIds=[INSTANCE_ID])

    while True:
        state = get_instance_state()
        logger.info(f"Waiting for instance to stop... Current state: {state}")
        if state == "stopped":
            logger.info("GPU instance successfully STOPPED.")
            return True
        time.sleep(5)
