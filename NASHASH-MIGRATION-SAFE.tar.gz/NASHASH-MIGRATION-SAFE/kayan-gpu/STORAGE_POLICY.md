# KayanGPU — سياسة التخزين النهائية (KAYAN-GPU-STORAGE-13)

جميع البيانات الدائمة على القرص الجذر EBS (/dev/root، 242GB).
لا يُستخدَم Instance Store (/opt/dlami/nvme) لأي بيانات يجب الحفاظ عليها،
لأنه مؤقت ويُفقد بالكامل عند Stop/Start.

## الخريطة الرسمية
| النوع | المسار | الحالة |
|---|---|---|
| Models (نماذج AI) | /data/models | دائم، لا يُحذف تلقائياً أبداً |
| Project inputs | /data/projects | دائم |
| Generated outputs (نتائج Worker) | /data/outputs | دائم - Worker يكتب هنا حصرياً (main.py: OUTPUT_DIR) |
| Temporary/cache | /data/cache | قابل للتنظيف الدوري (انظر أدناه) |
| Logs | /data/logs | دائم، يُراجَع يدوياً عند الحاجة |

## سياسة تنظيف Cache
- يُنظَّف /data/cache فقط (لا شيء آخر).
- يُحذف أي ملف عمره أكثر من 7 أيام.
- يُشغَّل يدوياً عبر: /opt/kayangpu/scripts/clean_cache.sh
- (لم يُضَف بعد كـ cron - يتطلب موافقة صريحة منفصلة لجدولة تلقائية)

## Worker Output Path
main.py يستخدم OUTPUT_DIR = "/data/outputs" بشكل صريح (سطر ثابت في الكود،
موثَّق هنا). كل Job ينتج ملف باسم: job_{job_id}.mp4 داخل هذا المسار حصرياً.
