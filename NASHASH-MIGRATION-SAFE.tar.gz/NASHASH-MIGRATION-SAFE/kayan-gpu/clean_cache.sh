#!/usr/bin/env bash
# KayanGPU - تنظيف /data/cache فقط، ملفات أقدم من 7 أيام
# لا يلمس models/projects/outputs/logs إطلاقاً
set -euo pipefail

CACHE_DIR="/data/cache"
DAYS_OLD=7

echo "=== KayanGPU Cache Cleanup - $(date) ==="
BEFORE=$(du -sh "$CACHE_DIR" 2>/dev/null | cut -f1)
echo "Cache size before: $BEFORE"

FOUND=$(find "$CACHE_DIR" -type f -mtime +$DAYS_OLD 2>/dev/null)
if [ -z "$FOUND" ]; then
  echo "لا توجد ملفات أقدم من $DAYS_OLD أيام - لا شيء يُحذف"
else
  echo "الملفات التي ستُحذف:"
  echo "$FOUND"
  find "$CACHE_DIR" -type f -mtime +$DAYS_OLD -delete
fi

AFTER=$(du -sh "$CACHE_DIR" 2>/dev/null | cut -f1)
echo "Cache size after: $AFTER"
