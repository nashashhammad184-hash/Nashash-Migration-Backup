# WORKER MAIN.PY PULL BLOCKED

STATUS=BLOCKED_AWS_INSUFFICIENT_CAPACITY
Reason: SSH to GPU instance (13.60.21.133:22) timing out; instance unreachable.
Attempted: scp /opt/kayangpu/api/main.py -> migration/kayan-gpu/worker_main.py (failed)

## What is present instead
- worker_main.TEMPLATE.py : local mirror of KayanGPU repo worker/main.py (7867 bytes, 2026-09-19 template, NOT production)
- The PRODUCTION worker main.py (sha256=c439eb0a..., 24043 bytes) is NOT copied here.

## To recover the production worker main.py
Once GPU is reachable (or via AWS Console session manager):
  scp -i ~/.ssh/kayan_gpu ubuntu@<gpu_ip>:/opt/kayangpu/api/main.py  $M/kayan-gpu/worker_main.py
  scp -i ~/.ssh/kayan_gpu ubuntu@<gpu_ip>:/opt/kayangpu/api/main.py.bak-20260929-130731 $M/kayan-gpu/worker_main.py.bak-20260929-130731

## Why not recovered from AWS Console directly
Session Manager (SSM) can push/pull files but requires interactive session; deferred per user instruction "no Stop/Start of GPU, no changes to instance".

## Known facts about production main.py (from session MASTER-I2V-INTEGRATION)
- sha256=c439eb0ab7f949c6e016fa9eaf56d0626e4c071169e142c6c073b510a93d807e
- size=24043 bytes
- mtime=2026-09-29 13:08 UTC
- Contains KAYAN-I2V-STEP-DISTILL patch:
    I2V_CKPT env (default /opt/dlami/nvme/hunyuan/ckpt/transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors)
    I2V_TRANSFORMER_NAME env (default "480p_i2v_step_distilled")
    I2V_DISTILL_METHOD = "dmd2"
    create_generator(..., distill_method=I2V_DISTILL_METHOD)
    sample_shift=7.0 (I2V only)
    denoising_step_list=[1000,875,750,625,500,375,250,125] (I2V only)
    T2V path unchanged
