# MIGRATION INVENTORY — Nashash / Kayan Studio

Generated: 2026-09-30
Purpose: classify every artifact so migration to a new provider is safe.

================================================================
A) SAFE TO PUT IN PRIVATE GITHUB
================================================================
- Nashash source code (/home/ubuntu/Nashash/{src,artifacts,lib,scripts})
- package.json, pnpm-lock.yaml, pnpm-workspace.yaml, tsconfig*.json
- .gitignore (already blocks .env, *.key, *.pem, *.dump)
- Migration scripts: scripts/restore_*.sh, scripts/verify_i2v_baseline.sh
- Non-secret manifests:
    manifests/NASHASH_SERVER_MANIFEST.txt
    manifests/I2V_BASELINE.txt
    manifests/MODEL_MANIFEST.txt
    manifests/KAYANGPU_MANIFEST.txt
    manifests/KNOWN_MIGRATION_NOTES.txt
    manifests/PROJECT_DATA_MANIFEST.txt
    manifests/.env.example.txt   (placeholders only, no real values)
- KayanGPU repo mirror (configs, systemd unit, worker TEMPLATE, docs)
- README.md (migration guide)
- gpu/GPU_ENVIRONMENT.txt (partial)

================================================================
B) MUST REMAIN PRIVATE (never push)
================================================================
- /home/ubuntu/Nashash/.env (DB URL with password, DEEPGRAM_API_KEY,
  GROQ_API_KEY, GOOGLE_API_KEY, FAL_KEY, GPU_WORKER_TOKEN,
  PRODUCTION_API_TOKEN)
- ~/.ssh/kayan_gpu (SSH private key to GPU instance)
- /home/ubuntu/.pm2/dump.pm2 (contains real GEMINI_API_KEY,
  DEEPGRAM_API_KEY, REPLICATE_API_TOKEN, GPU_WORKER_TOKEN)
- database/nashash_database.dump (contains full production data)
- database/kayan_queue.dump
- AWS credentials (~/.aws/credentials)
- TLS private keys
- Any /opt/kayangpu/api/.env on GPU side

================================================================
C) MUST BE RECREATED ON NEW HOST
================================================================
- Node.js runtime (v22.x) + npm (v9.x) + pnpm (v11.x)
- PostgreSQL server + role "user" + DB "dbname" + DB "kayan"
- Python 3.12 venv at /data/lightx2v_test/venv on GPU
- /data/models/video/hunyuanvideo-1.5/ckpts/ structure
- /data/lightx2v_test/venv/lib/python3.12/site-packages/lightx2v (v0.5.0)
- PM2 processes:
    nashash-app     → /home/ubuntu/Nashash/artifacts/api-server/dist/index.mjs
    nashash-queue   → /home/ubuntu/Nashash/artifacts/api-server/dist/queue-worker.mjs
    pm2-logrotate
- FFmpeg on both server and GPU
- CUDA 12.8 + PyTorch 2.8.0+cu128 on GPU
- /opt/kayangpu/api/main.py on GPU (see section E)
- ssh tunnel from Nashash → GPU (-L 8080:127.0.0.1:8080 -L 8082:127.0.0.1:8082)
- systemd unit /etc/systemd/system/kayangpu-worker.service on GPU

================================================================
D) MUST BE DOWNLOADED AGAIN
================================================================
- HunyuanVideo 1.5 480P I2V Step-Distilled transformer checkpoint
    Source: https://huggingface.co/tencent/HunyuanVideo-1.5
    Path:   transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors
    Size:   33,325,523,336 bytes (~33.3 GB)
    Target: /opt/dlami/nvme/hunyuan/ckpt/transformer/480p_i2v_step_distilled/
    Also needed: config.json (custom: use_meanflow=true),
                 additional.safetensors, byt5_mapper.safetensors
                 (last two symlinked from ../480p_i2v/)
- HunyuanVideo 1.5 base ckpts (if not present on new GPU):
    text_encoder/ (~15 GB, Qwen2.5-VL-7B-Instruct)
    vae/, vision_encoder/siglip/
    transformer/480p_t2v/diffusion_pytorch_model.safetensors (33 GB)

================================================================
E) BLOCKED UNTIL AWS GPU RETURNS
================================================================
- Exact production /opt/kayangpu/api/main.py
    Status = BLOCKED_AWS_INSUFFICIENT_CAPACITY
    Known: sha256=c439eb0a..., size=24043 B, mtime=2026-09-29 13:08 UTC
    Contains KAYAN-I2V-STEP-DISTILL patch.
- Exact GPU pip freeze
- Exact GPU nvidia-smi output
- Exact GPU driver version
- Confirmation that /opt/dlami/nvme checkpoint is still intact
- Confirmation of EBS attach state for /data/models/extra

================================================================
CHECKPOINT_BACKUP_STATUS
================================================================
CHECKPOINT_BACKUP_STATUS=NOT_SECURED
Reason: AWS GPU inaccessible. Checkpoint on Instance Store. No EBS/S3 copy confirmed.

================================================================
CRITICAL WARNING
================================================================
Do NOT stop / restart / terminate the current g5.xlarge instance until the
33.3 GB checkpoint is copied to EBS or S3. Instance Store is ephemeral.

================================================================
CREDENTIAL_STATUS (updated 2026-09-30)
================================================================
CREDENTIAL_STATUS=MANUAL_REQUIRED

Active credentials requiring rotation BEFORE migration:
  DEEPGRAM_API_KEY    (ACTIVE — auth validated 200; rotate at deepgram.com)
  GPU_WORKER_TOKEN    (ACTIVE — must rotate when GPU reachable; shared with GPU)

Inactive credentials exposed in pm2 dump (revoke or remove):
  GEMINI_API_KEY         (no code references)
  REPLICATE_API_TOKEN    (tests/legacy only)
  GOOGLE_API_KEY         (legacy only)
  GROQ_API_KEY           (check-env only)
  FAL_KEY                (legacy only)

Private backup of pre-rotation state (NOT in this package):
  /home/ubuntu/NASHASH-MIGRATION-PRIVATE/
  (contains env.backup-*, pm2_dump.backup-*, ROTATION_REQUIRED.md)

Details in ROTATION_REQUIRED.md (in the private dir only).
No secret values are recorded anywhere in this SAFE package.
