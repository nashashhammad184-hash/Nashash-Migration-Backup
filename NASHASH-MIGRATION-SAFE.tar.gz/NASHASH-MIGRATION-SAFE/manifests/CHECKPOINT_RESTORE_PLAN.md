# CHECKPOINT RESTORE PLAN

## Summary
The I2V Step-Distilled transformer checkpoint must be re-downloaded on the new
GPU host. All other model components survive on EBS.

## Source
- Repo: https://huggingface.co/tencent/HunyuanVideo-1.5
- File: transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors
- Size: ~33,325,523,336 bytes (33.3 GB)
- Config: transformer/480p_i2v_step_distilled/config.json

## Restore target on new GPU
# Option A — same as old layout (recommended for compatibility)
/data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/

# Option B — isolated location, requires env override in worker
/data/models/lightx2v/hy15_480p_i2v_step_distilled.safetensors
  → set KAYAN_I2V_CKPT=/data/models/lightx2v/hy15_480p_i2v_step_distilled.safetensors
  → set KAYAN_I2V_TRANSFORMER=480p_i2v_step_distilled

## Download (use venv hf CLI)
/data/lightx2v_test/venv/bin/hf download tencent/HunyuanVideo-1.5 \
  transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors \
  transformer/480p_i2v_step_distilled/config.json \
  --local-dir /data/models/video/hunyuanvideo-1.5/ckpts

## Required config override
The downloaded config.json has use_meanflow=true (correct for step-distilled).
Do NOT modify it.

## Symlinks to create after download
cd /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/
ln -sf ../480p_i2v/additional.safetensors additional.safetensors
ln -sf ../480p_i2v/byt5_mapper.safetensors byt5_mapper.safetensors
(the two symlinks already exist and survive on EBS)

## Verify after download
stat -c "%s" diffusion_pytorch_model.safetensors
# expected 33325523336

/data/lightx2v_test/venv/bin/python -c "
from safetensors import safe_open
p='/data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors'
with safe_open(p, framework='pt', device='cpu') as f:
    ks=list(f.keys())
    print('keys', len(ks))
    print('img_in.proj.weight', f.get_slice('img_in.proj.weight').get_shape())
"
# expected: keys 1797, shape (2048, 65, 1, 1, 1)

## Optional SHA256 (verify against HF revision metadata if provided)
sha256sum diffusion_pytorch_model.safetensors > diffusion_pytorch_model.safetensors.sha256

## Worker config reference
KAYAN_I2V_CKPT env var default:
  /opt/dlami/nvme/hunyuan/ckpt/transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors
(set KAYAN_I2V_CKPT to the NEW path if layout differs)
