# FINAL MIGRATION SETTINGS

No secret values. Settings only.

## ================ NASHASH ================
- Repository: /home/ubuntu/Nashash
- Workspace layout: pnpm workspace
- Node version: v22.x
- npm: 9.x, pnpm: 11.x
- Build: pnpm build  (studio + api-server)
- Start (pm2):
    nashash-app    → /home/ubuntu/Nashash/artifacts/api-server/dist/index.mjs
    nashash-queue  → /home/ubuntu/Nashash/artifacts/api-server/dist/queue-worker.mjs
- SSH key to GPU: /home/ubuntu/.ssh/kayan_gpu (private)

## ================ DATABASE ================
- PostgreSQL required
- Main DB name: dbname
- Queue DB name: kayan
- Dumps (NOT in SAFE archive):
    nashash_database.dump
    kayan_queue.dump
- Restore order:
    1) restore dbname
    2) restore kayan

## ================ GPU ================
- GPU: NVIDIA A10G (24 GB VRAM, 22.1 GB usable)
- Driver: 595.91.07 (min ~545 works with cu128)
- CUDA runtime: 12.8 (via PyTorch wheels)
- PyTorch: 2.8.0+cu128
- Python: 3.12.3
- FFmpeg: required on PATH
- LightX2V: 0.5.0
- Worker port: 8080 (localhost)
- SSH tunnel from Nashash → GPU: -L 8080:127.0.0.1:8080 -L 8082:127.0.0.1:8082
- systemd service: kayangpu-worker.service
- Queue requirements: single concurrent job (GPU 24GB)

## ================ I2V (verified working on 2026-09-29) ================
- model: HunyuanVideo 1.5 480P I2V Step-Distilled
- checkpoint_type: transformer (F32)
- distill_method: dmd2
- sample_shift: 7.0
- denoising_step_list: [1000, 875, 750, 625, 500, 375, 250, 125]
- guidance_scale: 1
- resolution: 640x640 output (480p bucket)
- frames: 81
- fps: 16
- reference image: required (base64 payload)
- Worker env overrides (optional):
    KAYAN_I2V_CKPT
    KAYAN_I2V_TRANSFORMER

## ================ STORAGE ================
- /data/models           — model weights (EBS-backed)
- /data/projects         — project data (EBS)
- /data/outputs          — final MP4 (EBS)
- /data/cache            — hf cache (EBS)
- /data/logs             — logs (EBS)
- /data/i2v_refs         — saved reference images per job (EBS)
- /data/lightx2v_test/venv — production Python venv (EBS)

## ================ SERVICES ================
- nashash-app    (pm2)
- nashash-queue  (pm2)
- pm2-logrotate  (pm2 module)
- kayangpu-worker (systemd on GPU)
- PostgreSQL     (systemd)

## ================ SECURITY ================
- PRODUCTION_API_TOKEN required by /api/video/generate
- GPU_WORKER_TOKEN required by worker (X-API-Key)
- All secrets via .env / environment only
- No secrets in git; .gitignore blocks .env, *.key, *.pem, *.dump
- SSH key for GPU stored at ~/.ssh/kayan_gpu (chmod 600)

## ================ CHECKPOINT STATUS (updated 2026-09-30) ================
CHECKPOINT_STATUS=LOST
CHECKPOINT_DURABLE_BACKUP=BLOCKED
CHECKPOINT_RESTORE_REQUIRED=YES

The 33.3 GB Step-Distilled transformer checkpoint was lost when the GPU
instance was stopped (AWS Instance Store does NOT persist across Stop/Start).
Surviving artifacts on EBS:
  - config.json for step_distilled transformer
  - additional.safetensors + byt5_mapper.safetensors (symlinks)
  - text_encoder, vae, vision_encoder
  - T2V FP8 checkpoint + old I2V CFG-Distilled FP8 checkpoint

MUST re-download from HuggingFace:
  tencent/HunyuanVideo-1.5
  transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors
  ~33,325,523,336 bytes
