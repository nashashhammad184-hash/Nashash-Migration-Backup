# NASHASH-MIGRATION SNAPSHOT

Created: 2026-09-30
Purpose: allow moving Nashash server + KayanGPU worker to a new provider without rebuilding.

## STATUS SUMMARY
- Nashash server snapshot: COMPLETE
- PostgreSQL dump: COMPLETE (dbname + kayan)
- PM2 config + dump: COMPLETE
- KayanGPU worker source: PARTIAL (template mirror copied; production main.py pull BLOCKED, GPU unreachable)
- GPU environment: BLOCKED_AWS_INSUFFICIENT_CAPACITY
- I2V baseline: DOCUMENTED (verified values from TASK-19)

## DIRECTORY
- manifests/  -> server, kayan, i2v, model, project data, migration notes
- gpu/        -> GPU_ENVIRONMENT.txt (partial)
- kayan-gpu/  -> KayanGPU repo mirror + local worker template
- database/   -> PostgreSQL dumps
- project-data/ (see PROJECT_DATA_MANIFEST.txt for source paths)
- scripts/    -> restore_*.sh + kayan_gpu SSH key

## CHECKPOINT_TRANSFER_REQUIRED=YES
- CHECKPOINT_SIZE=33325523336
- CURRENT_STORAGE=EPHEMERAL (AWS Instance Store /opt/dlami/nvme)
- SOURCE=tencent/HunyuanVideo-1.5 -> transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors

## CHECKPOINT TRANSFER PLAN (do NOT do until GPU reachable)
1) On current GPU (or new GPU), rsync checkpoint to S3 or EBS:
   aws s3 cp /opt/dlami/nvme/hunyuan/ckpt/transformer/480p_i2v_step_distilled/diffusion_pytorch_model.safetensors \
     s3://<your-bucket>/hunyuan/hy15_i2v_step_distilled.safetensors
2) Also upload config.json + additional.safetensors + byt5_mapper.safetensors
3) On new GPU: download into /data/models/video/hunyuanvideo-1.5/ckpts/transformer/480p_i2v_step_distilled/
4) Set KAYAN_I2V_CKPT env if path differs from default in worker.
5) Record sha256 for future integrity checks.

## CRITICAL WARNING
If the current g5.xlarge is stopped BEFORE transferring the checkpoint, the 33.3GB
checkpoint is lost and must be re-downloaded (~33GB) from HuggingFace.
